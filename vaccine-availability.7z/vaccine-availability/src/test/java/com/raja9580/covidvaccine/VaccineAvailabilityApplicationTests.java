package com.raja9580.covidvaccine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccineAvailabilityApplicationTests {

	@Test
	void contextLoads() {
	}

}
