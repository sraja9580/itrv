package com.raja9580.covidvaccine.pojos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"center_id",
"name",
"state_name",
"district_name",
"block_name",
"pincode",
"lat",
"long",
"from",
"to",
"fee_type",
"sessions"
})
@Generated("jsonschema2pojo")
public class Center {

@JsonProperty("center_id")
private Integer centerId;
@JsonProperty("name")
private String name;
@JsonProperty("state_name")
private String stateName;
@JsonProperty("district_name")
private String districtName;
@JsonProperty("block_name")
private String blockName;
@JsonProperty("pincode")
private Integer pincode;
@JsonProperty("lat")
private Integer lat;
@JsonProperty("long")
private Integer _long;
@JsonProperty("from")
private String from;
@JsonProperty("to")
private String to;
@JsonProperty("fee_type")
private String feeType;
@JsonProperty("sessions")
private List<Session> sessions = null;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("center_id")
public Integer getCenterId() {
return centerId;
}

@JsonProperty("center_id")
public void setCenterId(Integer centerId) {
this.centerId = centerId;
}

@JsonProperty("name")
public String getName() {
return name;
}

@JsonProperty("name")
public void setName(String name) {
this.name = name;
}

@JsonProperty("state_name")
public String getStateName() {
return stateName;
}

@JsonProperty("state_name")
public void setStateName(String stateName) {
this.stateName = stateName;
}

@JsonProperty("district_name")
public String getDistrictName() {
return districtName;
}

@JsonProperty("district_name")
public void setDistrictName(String districtName) {
this.districtName = districtName;
}

@JsonProperty("block_name")
public String getBlockName() {
return blockName;
}

@JsonProperty("block_name")
public void setBlockName(String blockName) {
this.blockName = blockName;
}

@JsonProperty("pincode")
public Integer getPincode() {
return pincode;
}

@JsonProperty("pincode")
public void setPincode(Integer pincode) {
this.pincode = pincode;
}

@JsonProperty("lat")
public Integer getLat() {
return lat;
}

@JsonProperty("lat")
public void setLat(Integer lat) {
this.lat = lat;
}

@JsonProperty("long")
public Integer getLong() {
return _long;
}

@JsonProperty("long")
public void setLong(Integer _long) {
this._long = _long;
}

@JsonProperty("from")
public String getFrom() {
return from;
}

@JsonProperty("from")
public void setFrom(String from) {
this.from = from;
}

@JsonProperty("to")
public String getTo() {
return to;
}

@JsonProperty("to")
public void setTo(String to) {
this.to = to;
}

@JsonProperty("fee_type")
public String getFeeType() {
return feeType;
}

@JsonProperty("fee_type")
public void setFeeType(String feeType) {
this.feeType = feeType;
}

@JsonProperty("sessions")
public List<Session> getSessions() {
return sessions;
}

@JsonProperty("sessions")
public void setSessions(List<Session> sessions) {
this.sessions = sessions;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((centerId == null) ? 0 : centerId.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Center other = (Center) obj;
	if (centerId == null) {
		if (other.centerId != null)
			return false;
	} else if (!centerId.equals(other.centerId))
		return false;
	return true;
}
 
}

