package com.raja9580.covidvaccine.pojos;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AvailableCenter{
	
@JsonProperty("center_id")
private Integer centerId;

@JsonProperty("name")
private String name;

@JsonProperty("block_name")
private String blockName;

@JsonProperty("pincode")
private Integer pincode;

@JsonProperty("sessions")
private List<Session> sessions = null;	

@JsonProperty("center_id")
public Integer getCenterId() {
return centerId;
}

@JsonProperty("center_id")
public void setCenterId(Integer centerId) {
this.centerId = centerId;
}

@JsonProperty("name")
public String getName() {
return name;
}

@JsonProperty("name")
public void setName(String name) {
this.name = name;
}

@JsonProperty("block_name")
public String getBlockName() {
return blockName;
}

@JsonProperty("block_name")
public void setBlockName(String blockName) {
this.blockName = blockName;
}

@JsonProperty("pincode")
public Integer getPincode() {
return pincode;
}

@JsonProperty("pincode")
public void setPincode(Integer pincode) {
this.pincode = pincode;
}

@JsonProperty("sessions")
public List<Session> getSessions() {
return sessions;
}

@JsonProperty("sessions")
public void setSessions(List<Session> sessions) {
this.sessions = sessions;
}

public void addSession(List<Session> sessions) {
	this.sessions.addAll(sessions);
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((centerId == null) ? 0 : centerId.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	AvailableCenter other = (AvailableCenter) obj;
	if (centerId == null) {
		if (other.centerId != null)
			return false;
	} else if (!centerId.equals(other.centerId))
		return false;
	return true;
} 

}