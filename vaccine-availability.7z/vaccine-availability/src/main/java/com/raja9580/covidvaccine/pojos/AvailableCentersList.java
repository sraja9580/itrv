package com.raja9580.covidvaccine.pojos;

import java.util.List;

public class AvailableCentersList {	
	private List<AvailableCenter> availableCenter = null;
}


