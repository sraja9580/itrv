package com.raja9580.covidvaccine.resource;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.raja9580.covidvaccine.pojos.AllCenters;
import com.raja9580.covidvaccine.pojos.AvailableCenter;
import com.raja9580.covidvaccine.pojos.Center;
import com.raja9580.covidvaccine.pojos.Session;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class GetAvailableSlots {

	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/getSlots")
	public List<AvailableCenter> getAvailableSlots() {

		List<AvailableCenter> availableCenter = new ArrayList<>();

		for (int i = 0; i < 4; i++) {
			LocalDate today = LocalDate.now().plusWeeks(i);
			String formattedDate = today.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
/*			AllCenters allCenters = restTemplate.getForObject(
					"https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByDistrict?district_id=571&date="
							+ formattedDate,
					AllCenters.class);*/
			AllCenters allCenters = restTemplate.getForObject(
					"https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByPin?pincode=600102&date="+ formattedDate,						
					AllCenters.class);
			
			addCenters(allCenters.getCenters(), availableCenter);
		}

		return availableCenter;
	}

	
	@GetMapping("/getSlotsByAge")
	public List<AvailableCenter> getAvailableSlots(@RequestParam int age) {

		List<AvailableCenter> availableCenter = new ArrayList<>();

		for (int i = 0; i < 10; i++) {
			LocalDate today = LocalDate.now().plusWeeks(i);
			String formattedDate = today.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
			AllCenters allCenters = restTemplate.getForObject(
					"https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByDistrict?district_id=571&date="
							+ formattedDate,
					AllCenters.class);			
			addCenters(allCenters.getCenters(), availableCenter,age);
		}

		return availableCenter;
	}
	private static List<AvailableCenter> addCenters(List<Center> allCenters,List<AvailableCenter> availableCentersLst){
		
		for(Center center : allCenters) {			
			List<Session> availableSlots = new ArrayList<Session>();			
			for(Session slot : center.getSessions()) {
				if(slot.getAvailableCapacity()>0) {
				//if(slot.getMinAgeLimit()==18 && slot.getAvailableCapacity()>0) {
					availableSlots.add(slot);
				}
			}			
			
			
			if(availableSlots.size()>0) {			
				AvailableCenter availableCenter = new AvailableCenter();
				availableCenter.setCenterId(center.getCenterId());
				if(availableCentersLst.contains(availableCenter)) {
					int index = availableCentersLst.indexOf(availableCenter);
					availableCenter = availableCentersLst.get(index);
					availableCentersLst.remove(index);
					availableCenter.addSession(availableSlots);					
					availableCentersLst.add(availableCenter);
				}else {				
					availableCenter.setCenterId(center.getCenterId());
					availableCenter.setName(center.getName());
					availableCenter.setBlockName(center.getBlockName());
					availableCenter.setPincode(center.getPincode());
					//if(availableSlots.size()>0) {
					availableCenter.setSessions(availableSlots);				
					availableCentersLst.add(availableCenter);
				}
			}
		}
		
		return availableCentersLst;
	}	
	 
private static List<AvailableCenter> addCenters(List<Center> allCenters,List<AvailableCenter> availableCentersLst,int minAge){
		
		for(Center center : allCenters) {			
			List<Session> availableSlots = new ArrayList<Session>();			
			for(Session slot : center.getSessions()) {
				//if(slot.getMinAgeLimit()==minAge) {
				if(slot.getMinAgeLimit()==minAge && slot.getAvailableCapacity()>0) {
					availableSlots.add(slot);
				}
			}			
			
			
			if(availableSlots.size()>0) {			
				AvailableCenter availableCenter = new AvailableCenter();
				availableCenter.setCenterId(center.getCenterId());
				if(availableCentersLst.contains(availableCenter)) {
					int index = availableCentersLst.indexOf(availableCenter);
					availableCenter = availableCentersLst.get(index);
					availableCentersLst.remove(index);
					availableCenter.addSession(availableSlots);					
					availableCentersLst.add(availableCenter);
				}else {				
					availableCenter.setCenterId(center.getCenterId());
					availableCenter.setName(center.getName());
					availableCenter.setBlockName(center.getBlockName());
					availableCenter.setPincode(center.getPincode());
					//if(availableSlots.size()>0) {
					availableCenter.setSessions(availableSlots);				
					availableCentersLst.add(availableCenter);
				}
			}
		}
		
		return availableCentersLst;
	}	
	public static void main(String args[]) {
		for(int i=0;i<4;i++) {
			LocalDate today =LocalDate.now().plusWeeks(i);
			String formattedDate = today.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
			System.out.println("::::"+formattedDate);
		}
	}
}
